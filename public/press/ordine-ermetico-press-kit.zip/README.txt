ORDINE ERMETICO · PRESS KIT
ordineermetico.com · Press enquiries: office@ordineermetico.com

APPROVED DESCRIPTIONS (EN)

One line:
Ordine Ermetico is a French company based in Reims that brings French houses to India.

Short:
Ordine Ermetico is a French company based in Reims, in the heart of Champagne. It brings French houses of Champagne, wine, luxury and beauty to India as their exclusive importer and distributor, and opens France and Europe to selected Indian brands.

Standard:
Ordine Ermetico is a French company based in Reims, in the heart of Champagne. It selects French houses of Champagne, wine, luxury and beauty that are not yet established in India, and builds their presence there as their exclusive importer and distributor: licensing, labelling, import, pricing and trade relationships handled by a single accountable partner. In the other direction, through its French company, Ordine Ermetico brings selected Indian brands to France and the European Union.

DESCRIPTIONS APPROUVÉES (FR)

Une ligne :
Ordine Ermetico est une société française basée à Reims qui accompagne des maisons françaises en Inde.

Courte :
Ordine Ermetico est une société française basée à Reims, au cœur de la Champagne. Elle accompagne en Inde des maisons françaises de Champagne, de vin, de luxe et de beauté en tant qu’importateur et distributeur exclusif, et ouvre la France et l’Europe à une sélection de marques indiennes.

LOGO USE
- Use the files supplied, unaltered. Gold logo on dark backgrounds; bronze logo on light backgrounds.
- Keep clear space around the logo at least the height of the letter O in the wordmark.
- Do not stretch, recolour, outline, add shadows or effects, or place the logo on busy images.
- Vector files are available on request.
- Partner houses' logos belong to the houses: please request them from the houses directly.

Name: always "Ordine Ermetico" (two words, capitalised), or "OE" after first mention.
